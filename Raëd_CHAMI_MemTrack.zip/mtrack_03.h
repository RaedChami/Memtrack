#ifndef MTRACK_03_H
#define MTRACK_03_H
#include <stddef.h>

void* _my_malloc(size_t taille);
void _my_free(void* adresse);

#endif