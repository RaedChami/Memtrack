#ifndef MTRACK_03_H
#define MTRACK_03_H
#include <stddef.h>

void* my_malloc(size_t taille);
void my_free(void* adresse);

#endif