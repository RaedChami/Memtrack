#ifndef _TRUC_MALLOC_H
#define _TRUC_MALLOC_H

void* my_malloc(size_t taille);

#endif