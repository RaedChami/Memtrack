#include <stdio.h>
#include <stdlib.h>

int main()
{
    char* ptr=(char*)malloc(1);
    fprintf(stderr,"adresse : %p -> valeur : %d \n",ptr,*ptr);
    return 0;
}