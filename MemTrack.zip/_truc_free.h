#ifndef _TRUC_FREE_H
#define _TRUC_FREE_H

void my_free(void* adresse);

#endif