#include <stdio.h>
#include <stdlib.h>
#include "track_01.h"

void my_free(void* adresse) {
    if (!adresse) { 
        table.cmpt_free_echouee++; 
        return;
    }
    for (int i = 0; i < table.taille; i++) {
        if (adresse == table.cellules[i].adresse) {
            if (!table.cellules[i].alloc) {
                table.cmpt_free_echouee++;
                fprintf(stderr, "Erreur Double Free\n");
                return;
            } else {
                free(adresse);
                table.cellules[i].alloc = false;
                table.cmpt_free_reussi++;
                table.cmpt_memoire_liberee += table.cellules[i].taille_allouee;
                return;
            }
        }
    }
    fprintf(stderr, "Adresse absente de Table, Libération de mémoire impossible!\n");
    table.cmpt_free_echouee++;
}
