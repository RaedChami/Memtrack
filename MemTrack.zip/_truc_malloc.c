#include <stdio.h>
#include <stdlib.h>
#include "track_01.h"

void* my_malloc(size_t taille) {
    void* adresse = malloc(taille);
    if (!adresse) exit(1);
    for (int i = 0; i < table.taille; i++) {
        if (adresse == table.cellules[i].adresse) {
            table.cellules[i].taille_allouee = taille;
            table.cellules[i].alloc = true;
            return adresse;
        }
    }

    if (table.taille >= table.capacite) {
        table.capacite *= 2;
        table.cellules = realloc(table.cellules, table.capacite * sizeof(Cellule));
        if (!table.cellules) {
            exit(1);
        }
    }


    table.cellules[table.taille].adresse = adresse;
    table.cellules[table.taille].taille_allouee = taille; 
    table.cellules[table.taille].alloc = true;
    table.taille++;
    table.cmpt_malloc++;
    table.cmpt_memoire_allouee++;
    printf("(0%d) malloc(%zu)->%p\n", table.cmpt_malloc, taille, adresse);
    return adresse;
}
